/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 *
 * Copyright (c) 2023-present, Ukama Inc.
 */

package ukama

import (
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestNodeId_GetNodeType(t *testing.T) {
	t.Run("NodeTypeValid", func(tt *testing.T) {
		ntypes := map[string]string{
			"HNode":     NODE_ID_TYPE_HOMENODE,
			"hnode":     NODE_ID_TYPE_HOMENODE,
			"HOMENODE":  NODE_ID_TYPE_HOMENODE,
			"Towernode": NODE_ID_TYPE_TOWERNODE,
			"tnode":     NODE_ID_TYPE_TOWERNODE,
			"TNODE":     NODE_ID_TYPE_TOWERNODE,
			"ANode":     NODE_ID_TYPE_AMPNODE,
			"anode":     NODE_ID_TYPE_AMPNODE,
			"ANODE":     NODE_ID_TYPE_AMPNODE,
			"CNode":     NODE_ID_TYPE_CNODE,
			"cnode":     NODE_ID_TYPE_CNODE,
			"CNODE":     NODE_ID_TYPE_CNODE}

		for k, v := range ntypes {
			nodeId := NewVirtualNodeId(k)
			assert.Equal(tt, v, nodeId.GetNodeType())
		}
	})

	t.Run("NodeTypeUndefined", func(tt *testing.T) {
		nodeId := NewVirtualNodeId("some_weird_type")
		assert.Equal(tt, NODE_ID_TYPE_UNDEFINED, nodeId.GetNodeType())
	})
}

func TestModuleId_StringLowercase(t *testing.T) {
	t.Run("ModuleTypeValid", func(tt *testing.T) {
		ntypes := map[string]string{
			"comv1": MODULE_ID_TYPE_COMP,
			"trx":   MODULE_ID_TYPE_TRX,
			"ctrl":  MODULE_ID_TYPE_CTRL,
			"fe":    MODULE_ID_TYPE_FE,
			"undef": MODULE_ID_TYPE_UNDEFINED}

		for k, v := range ntypes {
			moduleId := NewVirtualModuleId(k)
			assert.Contains(tt, moduleId.StringLowercase(), v)
		}
	})

	t.Run("ModuleTypeUndefined", func(tt *testing.T) {
		moduleId := NewVirtualModuleId("some_weird_type")
		assert.Contains(tt, moduleId.StringLowercase(), MODULE_ID_TYPE_UNDEFINED)
	})
}

func TestGetNodeType(t *testing.T) {
	t.Run("NodeTypeValid", func(tt *testing.T) {
		ntypes := map[string]string{
			"HNode":     NODE_ID_TYPE_HOMENODE,
			"hnode":     NODE_ID_TYPE_HOMENODE,
			"HOMENODE":  NODE_ID_TYPE_HOMENODE,
			"Towernode": NODE_ID_TYPE_TOWERNODE,
			"tnode":     NODE_ID_TYPE_TOWERNODE,
			"TNODE":     NODE_ID_TYPE_TOWERNODE,
			"ANode":     NODE_ID_TYPE_AMPNODE,
			"anode":     NODE_ID_TYPE_AMPNODE,
			"ANODE":     NODE_ID_TYPE_AMPNODE,
			"CNode":     NODE_ID_TYPE_CNODE,
			"cnode":     NODE_ID_TYPE_CNODE,
			"CNODE":     NODE_ID_TYPE_CNODE}

		for k, v := range ntypes {
			nodeId := NewVirtualNodeId(k)
			nodeType := GetNodeType(nodeId.StringLowercase())
			assert.Equal(tt, v, *nodeType)
		}
	})
}

func TestValidateNodeId(t *testing.T) {
	t.Run("NodeIdIsValid", func(tt *testing.T) {
		nodeId := "UK-SA2156-HNODE-A1-XXXX"

		uid, err := ValidateNodeId(string(nodeId))

		assert.NoError(tt, err)
		assert.Equal(tt, strings.ToLower(nodeId), string(uid))
	})
	t.Run("NodeIdIsValid", func(tt *testing.T) {
		nodeId := "UK-SA2156-CNODE-A1-XXXX"

		uid, err := ValidateNodeId(string(nodeId))

		assert.NoError(tt, err)
		assert.Equal(tt, strings.ToLower(nodeId), string(uid))
	})

	t.Run("ValidateNodeIdCase1", func(tt *testing.T) {
		nodeId := "UK-SA2156"

		_, err := ValidateNodeId(string(nodeId))
		assert.Error(tt, err)
	})

	t.Run("ValidateNodeIdCase2", func(tt *testing.T) {
		// Valid length but node code is not hnode/anode/tnode/cnode (e.g. undef).
		nodeId := "UK-SA2156-undef-A1-XXXX"

		_, err := ValidateNodeId(string(nodeId))
		assert.Error(tt, err)
	})
}

func TestGetANodeIdFromTNodeId(t *testing.T) {
	t.Run("InvalidLength", func(tt *testing.T) {
		id, err := GetANodeIdFromTNodeId("too-short")
		assert.Error(tt, err)
		assert.Equal(tt, NodeID(""), id)
	})

	t.Run("Valid_TNodeToANodeAndLowercase", func(tt *testing.T) {
		tNodeId := "UK-SA2156-TNODE-A1-XXXX"

		aNodeId, err := GetANodeIdFromTNodeId(tNodeId)
		assert.NoError(tt, err)
		assert.Equal(tt, NodeID("uk-sa2156-anode-a1-xxxx"), aNodeId)
	})
}

func TestGetCNodeIdFromTNodeId(t *testing.T) {
	t.Run("InvalidLength", func(tt *testing.T) {
		id, err := GetCNodeIdFromTNodeId("too-short")
		assert.Error(tt, err)
		assert.Equal(tt, NodeID(""), id)
	})

	t.Run("Valid_TNodeToCNodeAndLowercase", func(tt *testing.T) {
		tNodeId := "UK-SA2156-TNODE-A1-XXXX"

		cNodeId, err := GetCNodeIdFromTNodeId(tNodeId)
		assert.NoError(tt, err)
		assert.Equal(tt, NodeID("uk-sa2156-cnode-a1-xxxx"), cNodeId)
	})
}

func TestValidateNodeIdAndType(t *testing.T) {
	t.Run("ValidNodeIDAndType", func(tt *testing.T) {
		nodeID := "UK-SA2602-CNODE-V0-344C"

		nID, nodeType, err := ValidateNodeIdAndType(nodeID)

		assert.NoError(tt, err)
		assert.Equal(tt, NodeID("uk-sa2602-cnode-v0-344c"), nID)
		if assert.NotNil(tt, nodeType) {
			assert.Equal(tt, NODE_ID_TYPE_CNODE, *nodeType)
		}
	})

	t.Run("InvalidNodeIDReturnsError", func(tt *testing.T) {
		nID, nodeType, err := ValidateNodeIdAndType("invalid-node-id")

		assert.Error(tt, err)
		assert.Equal(tt, NodeID(""), nID)
		assert.Nil(tt, nodeType)
	})
}
