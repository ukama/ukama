/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 *
 * Copyright (c) 2023-present, Ukama Inc.
 */

package ukama

import (
	"errors"
	"fmt"
	"math/rand"
	"strconv"
	"strings"
	"time"

	log "github.com/sirupsen/logrus"
)

const (
	CODE_IDX     = 10
	NodeIDLength = 23
	OEMCODE      = "UK"
	MFGCODE      = "SA"
	DELIMITER    = "-"
	HWVERSION    = "M0"
	UNITVERSION  = "V0"

	NODE_ID_TYPE_HOMENODE  = "hnode"
	NODE_ID_TYPE_TOWERNODE = "tnode"
	NODE_ID_TYPE_AMPNODE   = "anode"
	NODE_ID_TYPE_UNDEFINED = "undef"
	NODE_ID_TYPE_CNODE     = "cnode"

	MODULE_ID_TYPE_COMP      = "comv1"
	MODULE_ID_TYPE_TRX       = "trx"
	MODULE_ID_TYPE_CTRL      = "ctrl"
	MODULE_ID_TYPE_FE        = "fe"
	MODULE_ID_TYPE_UNDEFINED = "undef"
)

const (
	placeholder_component_type_home      = "Home node"
	placeholder_component_type_tower     = "Tower node"
	placeholder_component_type_amplifier = "Amplifier node"
	placeholder_component_type_cnode     = "Controller node"
	placeholder_component_type_undefined = "Undefined node"
)

var nodeTypeToPlaceholderName = map[string]string{
	NODE_ID_TYPE_HOMENODE:  placeholder_component_type_home,
	NODE_ID_TYPE_TOWERNODE: placeholder_component_type_tower,
	NODE_ID_TYPE_CNODE:     placeholder_component_type_cnode,
	NODE_ID_TYPE_AMPNODE:   placeholder_component_type_amplifier,
}

// Sentinel errors returned by ValidateNodeId.
var (
	ErrInvalidNodeIDLength = errors.New("invalid length")
	ErrInvalidNodeIDCode   = errors.New("invalid Node Code")
)

var validNodeIDTypeCodes = map[string]struct{}{
	NODE_ID_TYPE_HOMENODE:  {},
	NODE_ID_TYPE_AMPNODE:   {},
	NODE_ID_TYPE_TOWERNODE: {},
	NODE_ID_TYPE_CNODE:     {},
}

type NodeID string

type ModuleID string

func (n NodeID) String() string {
	return string(n)
}

func (n NodeID) StringLowercase() string {
	return strings.ToLower(n.String())
}

func (m ModuleID) String() string {
	return string(m)
}

func (m ModuleID) StringLowercase() string {
	return strings.ToLower(m.String())
}

func (n NodeID) GetNodeType() string {
	t := n.String()[CODE_IDX : CODE_IDX+strings.IndexRune(n.String()[CODE_IDX:], '-')]
	switch strings.ToLower(t) {
	case NODE_ID_TYPE_HOMENODE:
		return NODE_ID_TYPE_HOMENODE

	case NODE_ID_TYPE_AMPNODE:
		return NODE_ID_TYPE_AMPNODE

	case NODE_ID_TYPE_TOWERNODE:
		return NODE_ID_TYPE_TOWERNODE

	case NODE_ID_TYPE_CNODE:
		return NODE_ID_TYPE_CNODE

	default:
		return NODE_ID_TYPE_UNDEFINED
	}
}

func getRandCode(t time.Time) string {
	r := rand.New(rand.NewSource(time.Now().UnixNano()))

	min := 0x0000
	max := 0xFFFF
	val := r.Intn(max-min+1) + min
	hexcode := fmt.Sprintf("%04X", val)
	return hexcode
}

/* Get HW Code */
func GetNodeCodeForUnits(ntype string) string {
	var code string
	switch strings.ToLower(ntype) {
	case NODE_ID_TYPE_HOMENODE, "homenode":
		code = NODE_ID_TYPE_HOMENODE
	case NODE_ID_TYPE_TOWERNODE, "towernode":
		code = NODE_ID_TYPE_TOWERNODE
	case NODE_ID_TYPE_AMPNODE, "ampnode":
		code = NODE_ID_TYPE_AMPNODE
	case NODE_ID_TYPE_CNODE, "ctrlnode":
		code = NODE_ID_TYPE_CNODE
	default:
		code = NODE_ID_TYPE_UNDEFINED
	}
	return code
}

/* Get HW Code */
func GetModuleCodeForUnits(mtype string) string {
	var code string
	switch strings.ToLower(mtype) {
	case MODULE_ID_TYPE_COMP, "com":
		code = MODULE_ID_TYPE_COMP
	case MODULE_ID_TYPE_TRX, "transciever":
		code = MODULE_ID_TYPE_TRX
	case MODULE_ID_TYPE_CTRL, "control":
		code = MODULE_ID_TYPE_CTRL
	case MODULE_ID_TYPE_FE, "rffe", "frontend":
		code = MODULE_ID_TYPE_FE
	default:
		code = MODULE_ID_TYPE_UNDEFINED
	}
	return code
}

/* Generate new node id for virtual node */
func NewVirtualNodeId(ntype string) NodeID {
	t := time.Now()
	year, week := t.ISOWeek()
	yearstr := strconv.Itoa(year)
	yearcode := yearstr[len(yearstr)-2:]
	weekstr := fmt.Sprintf("%02d", week)
	code := GetNodeCodeForUnits(ntype)

	/*2+1+6+1+5+1+2+1+4*/
	/* UK-SA2154-HNODE-A1-XXXX*/
	uuid := OEMCODE + DELIMITER + MFGCODE + yearcode + weekstr + DELIMITER + code + DELIMITER + UNITVERSION + DELIMITER + getRandCode(t)

	log.Infof("UUID: New NodeID for %s is %s and length is %d", ntype, uuid, len(uuid))

	/* RFC 1123 lowercase id and tags*/
	lid := strings.ToLower(uuid)

	return NodeID(lid)
}

/* Generate new module id for virtual module */
func NewVirtualModuleId(mtype string) ModuleID {
	t := time.Now()
	year, week := t.ISOWeek()
	yearstr := strconv.Itoa(year)
	yearcode := yearstr[len(yearstr)-2:]
	weekstr := fmt.Sprintf("%02d", week)
	code := GetModuleCodeForUnits(mtype)

	/*2+1+6+1+5+1+2+1+4*/
	/* UK-SA2154-HNODE-A1-XXXX*/
	uuid := OEMCODE + DELIMITER + MFGCODE + yearcode + weekstr + DELIMITER + code + DELIMITER + HWVERSION + DELIMITER + getRandCode(t)

	log.Infof("UUID: New ModuleID for %s is %s and length is %d", mtype, uuid, len(uuid))

	/* RFC 1123 lowercase id and tags*/
	lid := strings.ToLower(uuid)

	return ModuleID(lid)
}

func NewVirtualComId() ModuleID {
	return NewVirtualModuleId(MODULE_ID_TYPE_COMP)
}

func NewVirtualTRXId() ModuleID {
	return NewVirtualModuleId(MODULE_ID_TYPE_TRX)
}

func NewVirtualCtrlId() ModuleID {
	return NewVirtualModuleId(MODULE_ID_TYPE_CTRL)
}

func NewVirtualFEId() ModuleID {
	return NewVirtualModuleId(MODULE_ID_TYPE_FE)
}

// Generate new node id for home node
func NewVirtualHomeNodeId() NodeID {
	return NewVirtualNodeId(NODE_ID_TYPE_HOMENODE)
}

// Generate new node id for amplifier node
func NewVirtualAmplifierNodeId() NodeID {
	return NewVirtualNodeId(NODE_ID_TYPE_AMPNODE)
}

// Generate new node id for tower node
func NewVirtualTowerNodeId() NodeID {
	return NewVirtualNodeId(NODE_ID_TYPE_TOWERNODE)
}

func GetNodeType(n string) *string {
	codes := [...]string{
		NODE_ID_TYPE_HOMENODE,
		NODE_ID_TYPE_TOWERNODE,
		NODE_ID_TYPE_AMPNODE,
		NODE_ID_TYPE_CNODE}

	var nodeType *string
	for _, code := range codes {
		/* Check for the NodeTyope codes */
		if strings.Contains(strings.ToLower(n), code) {

			/* Check index of substring */
			idx := strings.Index(strings.ToLower(n), code)
			if idx == CODE_IDX {
				nodeType = &code
				break
			}
		}
	}

	return nodeType
}

func GetPlaceholderNameByType(nodeType string) string {
	if name, ok := nodeTypeToPlaceholderName[strings.ToLower(nodeType)]; ok {
		return name
	}
	return placeholder_component_type_undefined
}

// nodeTypeSegmentFromLowerID returns the hardware node-type token at CODE_IDX up to
// the next '-', matching NodeID.GetNodeType parsing rules.
func nodeTypeSegmentFromLowerID(lid string) (string, bool) {
	if len(lid) <= CODE_IDX {
		return "", false
	}
	rest := lid[CODE_IDX:]
	i := strings.IndexRune(rest, '-')
	if i < 0 {
		return "", false
	}
	return rest[:i], true
}

func ValidateNodeId(id string) (NodeID, error) {
	/* TODO :: ADD more validation once we finalized this format */
	if len(id) != NodeIDLength {
		return "", ErrInvalidNodeIDLength
	}

	lid := strings.ToLower(id)
	seg, ok := nodeTypeSegmentFromLowerID(lid)
	if !ok {
		return "", ErrInvalidNodeIDCode
	}
	if _, valid := validNodeIDTypeCodes[seg]; !valid {
		return "", ErrInvalidNodeIDCode
	}

	/* RFC 1123 lowercase id and tags*/
	return NodeID(lid), nil
}

func GetANodeIdFromTNodeId(tNodeId string) (NodeID, error) {
	if len(tNodeId) != NodeIDLength {
		return "", ErrInvalidNodeIDLength
	}

	tNodeId = strings.ToLower(tNodeId)

	return NodeID(strings.Replace(tNodeId, NODE_ID_TYPE_TOWERNODE, NODE_ID_TYPE_AMPNODE, 1)), nil
}

func GetCNodeIdFromTNodeId(tNodeId string) (NodeID, error) {
	if len(tNodeId) != NodeIDLength {
		return "", ErrInvalidNodeIDLength
	}

	tNodeId = strings.ToLower(tNodeId)

	return NodeID(strings.Replace(tNodeId, NODE_ID_TYPE_TOWERNODE, NODE_ID_TYPE_CNODE, 1)), nil
}

func ValidateNodeIdAndType(nodeID string) (NodeID, *string, error) {
	nID, err := ValidateNodeId(nodeID)
	if err != nil {
		return "", nil, err
	}

	nodeType := GetNodeType(nID.String())
	return nID, nodeType, nil
}