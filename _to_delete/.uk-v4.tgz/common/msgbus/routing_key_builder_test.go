/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 *
 * Copyright (c) 2023-present, Ukama Inc.
 */

package msgbus

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestBuild(t *testing.T) {

	t.Run("basic_usage", func(t *testing.T) {
		rk, err := NewRoutingKeyBuilder().SetEventType().SetCloudSource().SetObject("some-obj").
			SetAction("create").SetCloudSource().SetGlobalScope().SetOrgName("org").SetSystem("system").SetService("some_container").Build()
		assert.NoError(t, err)
		assert.Equal(t, "event.cloud.global.org.system.some_container.some-obj.create", rk)
	})

	t.Run("use_star_segment", func(t *testing.T) {
		rk, err := NewRoutingKeyBuilder().SetEventType().SetCloudSource().SetObject("some-obj").
			SetAction("*").SetCloudSource().SetOrgName("org").SetSystem("system").SetService("some_container").Build()
		assert.NoError(t, err)
		assert.Equal(t, "event.cloud.local.org.system.some_container.some-obj.*", rk)
	})

	t.Run("error_missing_segment", func(t *testing.T) {
		_, err := NewRoutingKeyBuilder().SetEventType().SetCloudSource().
			SetAction("*").SetGlobalScope().SetOrgName("org").SetSystem("system").SetService("some_container").Build()
		assert.Error(t, err, "")
		assert.EqualErrorf(t, err, "object segment is not set", "")

	})

	t.Run("make_sure_new_instace_is_created", func(t *testing.T) {
		rk := NewRoutingKeyBuilder()
		rk1 := rk.SetEventType().SetCloudSource().
			SetAction("*").SetCloudSource().SetGlobalScope().SetOrgName("org").SetSystem("system").SetService("container1")

		rk2 := rk.SetEventType().SetCloudSource().
			SetAction("*").SetCloudSource().SetGlobalScope().SetOrgName("org").SetSystem("system").SetService("container2")

		assert.NotEqual(t, rk1, rk2)
	})

	t.Run("GlobalKeyUpdateToAccpetFromAllOrg", func(t *testing.T) {
		rk := NewRoutingKeyBuilder()
		rk1 := rk.SetEventType().SetCloudSource().
			SetActionUpdate().SetCloudSource().SetGlobalScope().SetOrgName("org").SetSystem("system").SetService("service").SetObject("object").MustBuild()
		newKey := UpdateToAcceptFromAllOrg(rk1)
		assert.Equal(t, "event.cloud.global.*.system.service.object.update", newKey)
	})

	t.Run("LocalKeyUpdateToAccpetFromAllOrg", func(t *testing.T) {
		rk := NewRoutingKeyBuilder()
		rk1 := rk.SetEventType().SetCloudSource().
			SetActionUpdate().SetCloudSource().SetLocalScope().SetOrgName("org").SetSystem("system").SetService("service").SetObject("object").MustBuild()
		newKey := UpdateToAcceptFromAllOrg(rk1)
		assert.Equal(t, "event.cloud.local.org.system.service.object.update", newKey)
	})

	t.Run("Parse", func(t *testing.T) {
		route := "event.cloud.local.ukama.operator.cdr.sim.usage"
		_, err := Parse(route)
		assert.NoError(t, err)
	})
}
