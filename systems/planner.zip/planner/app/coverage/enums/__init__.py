from enum import Enum


class BaseEnum(Enum):
    pass
