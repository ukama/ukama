#!/bin/bash
conda run -n myenv python main.py --env dev --debug
